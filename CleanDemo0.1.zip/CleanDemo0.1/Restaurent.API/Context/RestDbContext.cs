﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Context
{
    public class RestDbContext:DbContext
    {
        public RestDbContext(DbContextOptions<RestDbContext> options) : base(options)
        {

        }

        public DbSet<Item> item { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<User> users { get;set; }

        public DbSet<Bill> bills { get; set; }

        public DbSet<OrderItem> orderItem { get; set; }
        public DbSet<OrderStatus> orderStatus { get; set; }

      
        public DbSet<Role> roles { get; set; }
        public DbSet<User_Role> userRoles { get; set; }
    }

}