﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Restaurent.Infrastructure.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly IUnitOfWork unitOfWork;

        public GenericRepository(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<T> AddAsync(T entity)
        {
            try
            {
                await unitOfWork.Context.Set<T>().AddAsync(entity);
                await unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> DeleteAsync(int id)
        {
            try
            {
                var entity = await unitOfWork.Context.Set<T>().FindAsync(id);

                if (entity == null)
                {
                    return null;
                }

                unitOfWork.Context.Set<T>().Remove(entity);
                await unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            try
            {
                return await unitOfWork.Context.Set<T>().ToListAsync();
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> GetAsync(int id)
        {
            try
            {
                return await unitOfWork.Context.Set<T>().FindAsync(id);
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<T> UpdateAsync(int id, T entity)
        {
            try
            {
                var updatedEntity = await unitOfWork.Context.Set<T>().FindAsync(id);
                if (updatedEntity == null)
                {
                    return null;
                }

                unitOfWork.Context.Set<T>().Update(entity);
                await unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
