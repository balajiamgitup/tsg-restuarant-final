﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Resaturent.UI.Tests.MockData
{
    public class OrderMockData
    {
        public static List<Restaurent.Domain.Entities.Order> GetOrders()
        {

            return new List<Restaurent.Domain.Entities.Order>
            {
           new Restaurent.Domain.Entities.Order
           {
               orderId= 455,
               tablenumber= 43,
               statusId= 1,
               userId= 101
           },
             new Restaurent.Domain.Entities.Order
           {
               orderId= 459,
               tablenumber= 46,
               statusId= 6,
               userId= 100
           },
            };
        }

        public static Restaurent.Domain.Entities.Order AddOrders()
        {
            return new Restaurent.Domain.Entities.Order
            {
                orderId = 459,
                tablenumber = 46,
                statusId = 6,
                userId = 100
            };
        }
    }
}