﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class UserRepository : IUserRepository
    {




        private List<User> Users = new List<User>()
          {
              new User()
              {
                  UserId = 100, name = "anki", password = "anki@waiter.com",
             Roles = new List<string> { "waiter" }
              },
           new User()
             {
                UserId =101, name = "balaji", password = "balaji@staff.com",
               Roles = new List<string> { "staff" }
             }
          };

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = Users.Find(x => x.name.Equals(username, StringComparison.InvariantCultureIgnoreCase) &&
           x.password == password);

            return user;


        }
    }
}
