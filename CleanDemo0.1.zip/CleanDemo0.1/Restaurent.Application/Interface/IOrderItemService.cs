﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{
    public interface IOrderItemService
    {

        Task<IEnumerable<OrderItem>> GetAllOrderItemAsync();

        Task<OrderItem> GetOrderItemAsync(int orderItemId);
        Task<OrderItem> AddAOrdersync(OrderItem orderItems);

        Task<OrderItem> DeleteOrderItemAsync(int orderItemId);

        Task<OrderItem> UpdateOrderItemAsync(int orderItemId, OrderItem orders);
    }
}
