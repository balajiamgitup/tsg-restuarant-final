﻿using Moq;
using Resaturent.UI.Tests.MockData;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Resaturent.Tests.Restaurent.Application.Tests
{
    public class TestOrderService
    {
        private readonly OrderService _orderService;
      
        private readonly Mock<IOrderRepository> _orderRepositoryMock;

        public TestOrderService()
        {
            _orderRepositoryMock = new Mock<IOrderRepository>();
            _orderService = new OrderService(_orderRepositoryMock.Object);
        }
      
        [Fact]
        public async Task AddOrderAsync_Should_Return_Order_When_Called()
        {
            //Arrange
            var order = new Order { orderId = 1, tablenumber = 1, statusId = 1, userId = 1 };
            _orderRepositoryMock.Setup(x => x.AddAsync(order)).ReturnsAsync(order);

            // Act
            var result = await _orderService.AddAsync(order);
            _orderRepositoryMock.Verify(x => x.AddAsync(order), Times.Once());
            // Assert
            Assert.NotNull(result);
            Assert.IsType<Order>(result);
            Assert.Equal(1, result.orderId);
        }

        [Fact]
        public async Task DeleteOrderAsync_Should_Return_Order_When_Called()
        {
              // Arrange
            var orderItemId = 1;
            var order = new Order { orderId = 1, tablenumber = 1, statusId = 1, userId = 1 };
            _orderRepositoryMock.Setup(x => x.DeleteAsync(orderItemId)).ReturnsAsync(order);

            // Act
            var result = await _orderService.DeleteAsync(orderItemId);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<Order>(result);
            Assert.Equal(1, result.orderId);
        }
        [Fact]
        public async Task GetAllOrderAsync_Should_Return_IEnumerable_Order_When_Called()
        {
            // Arrange
            var orderItems = new List<Order>
        {
            new Order { orderId = 1, tablenumber = 1, statusId = 1, userId = 1 },
            new Order { orderId = 2, tablenumber = 2, statusId = 2, userId = 2 }
        };
            _orderRepositoryMock.Setup(x => x.GetAllAsync()).ReturnsAsync(orderItems);

            // Act
            var result = await _orderService.GetAllOrderAsync();

            // Assert
            Assert.NotNull(result);
            Assert.IsType<List<Order>>(result);
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task UpdateAsync_Should_Return_Order_When_Called()
        {
            // Arrange
            var orderId = 1;
            var order = new Order { orderId = 1, tablenumber = 1, statusId = 1, userId = 1 };
            _orderRepositoryMock.Setup(x => x.UpdateAsync(orderId, order)).ReturnsAsync(order);

            // Act
            var result = await _orderService.UpdateAsync(orderId, order);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<Order>(result);
            Assert.Equal(1, result.orderId);
        }

        [Fact]      
        public async Task GetOrderAsync_Should_Return_Order_When_Called()
        {
            // Arrange
            var orderId = 1;
            var order = new Order { orderId = 1, tablenumber = 1, statusId = 1, userId = 1 };
            _orderRepositoryMock.Setup(x => x.GetAsync(orderId)).ReturnsAsync(order);

            // Act
            var result = await _orderService.GetOrdeAsync(orderId);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<Order>(result);
            Assert.Equal(1, result.orderId);
        }
    }
}
