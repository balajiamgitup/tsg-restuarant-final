﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class Item
    {
        [Key]
        public Guid itemId { get; set; }
        public string name { get; set; }
        public int price { get; set; }

        public DateTime updatedDate { get; set; }

        public Guid UserId { get; set; }
    }
}
