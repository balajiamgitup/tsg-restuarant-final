﻿using DocumentFormat.OpenXml.Drawing.Charts;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class OrderItemService : IOrderItemService
    {


        private readonly IOrderItemRepository _orderItemRepository;

        public OrderItemService(IOrderItemRepository orderItemRepository)
        {
            this._orderItemRepository = orderItemRepository;
        }

        public async Task<OrderItem> AddAOrdersync(OrderItem orderItems)
        {
            return await _orderItemRepository.AddAsync(orderItems);
        }

        public async Task<OrderItem> DeleteOrderItemAsync(int orderItemId)
        {
            return await _orderItemRepository.DeleteAsync(orderItemId);
        }

        public async Task<IEnumerable<OrderItem>> GetAllOrderItemAsync()
        {
          return await _orderItemRepository.GetAllAsync();
        }

        public async Task<OrderItem> GetOrderItemAsync(int orderItemId)
        {
            return await _orderItemRepository.GetAsync(orderItemId);
        }

        public async Task<OrderItem> UpdateOrderItemAsync(int orderItemId, OrderItem orders)
        {
            return await _orderItemRepository.UpdateAsync(orderItemId, orders);
        }
    }
}
