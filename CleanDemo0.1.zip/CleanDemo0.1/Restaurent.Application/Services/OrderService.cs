﻿using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class OrderService : IOrderService
    {

        private readonly IOrderRepository _orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            this._orderRepository = orderRepository;
        }

        public async Task<Order> AddAsync(Order orders)
        {
            return await _orderRepository.AddAsync(orders);
        }

        public Task<Order> DeleteAsync(int orderId)
        {
           return _orderRepository.DeleteAsync(orderId);
        }

        public async Task<IEnumerable<Order>> GetAllOrderAsync()
        {
            return await _orderRepository.GetAllAsync();
        }

        public async Task<Order> GetOrdeAsync(int orderId)
        {
            return await _orderRepository.GetAsync( orderId);
        }

        public async Task<Order> UpdateAsync(int orderId, Order orders)
        {
            return await _orderRepository.UpdateAsync( orderId, orders);
        }


    }
}
